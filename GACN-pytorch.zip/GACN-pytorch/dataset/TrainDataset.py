import os.path as osp
import numpy as np
import torch
import random
import cv2
from torch.utils import data
import pickle
from PIL import Image
from torchvision.transforms import ToPILImage

class TrainDataset(data.Dataset):
    def __init__(self, train):
        self.files = []
        self.train = train
    
    
    def __len__(self):
        return len(self.train)

    
    def __getitem__(self, index):
        image, label = self.train[index]
        
        img = ToPILImage()(image)
        

        return image, label
        

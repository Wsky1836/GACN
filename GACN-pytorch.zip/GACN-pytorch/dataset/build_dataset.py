# %%
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


import torch
import torchvision.transforms as transform
from torchvision.utils import save_image
from torch.utils.data import DataLoader
from torchvision import datasets
from torch.utils import data
from torchvision.datasets import ImageFolder
from torchvision.transforms import ToPILImage
import random
import cv2
import os
import os.path as osp
import numpy as np
from torchvision import transforms

import pandas as pd
import matplotlib.pyplot as plt
from torch.utils.data import *
import json
import torchvision.transforms as transforms

from PIL import Image
# %%
def default_loader(path):
    return Image.open(path).convert('RGB')

class MyDataSet(Dataset):
    def __init__(self, train ,transform=None,target_transform=None,loader=default_loader):

        
        self.transform=transform
        self.target_transform=target_transform
        self.loader=loader

        list_path = train

        img_ids = [i_id.strip() for i_id in open(list_path)]
        self.files = []

        for name in img_ids:
            img_file = name
            #print(img_file)
            label = img_file.split("/")[6]
            #print(label)


            self.files.append({
                "img": img_file,
                "label": label,
            })

    def __getitem__(self,index):
        data = self.files[index]
        img=self.loader(data["img"])
        label = data["label"]

        if self.transform is not None:
            img=self.transform(img)
        if self.target_transform is not None:
            label=self.target_transform(label)


        return img,int(label)
    
    def __len__(self):
        return len( self.files)
    
def preprocess_with_augmentation(image_size):
    return transforms.Compose([
        transforms.Resize((image_size, image_size)),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor()
    ])



def preprocess(image_size):
    return transforms.Compose([
        transforms.Resize((image_size, image_size)),
        transforms.ToTensor()
    ])

def getdDataset(opt):

    train_dir = "/home/wick/datasets/AC-82/train.txt"
    valid_dir = "/home/wick/datasets/AC-82/valid.txt"

    IMAGE_SIZE=128

    train_loader = data.DataLoader(
                        MyDataSet(train_dir, transform=preprocess_with_augmentation(IMAGE_SIZE)),
                batch_size=128, shuffle=True, num_workers=8, drop_last = True)

    val_loader = data.DataLoader(
                        MyDataSet(valid_dir, transform=preprocess(IMAGE_SIZE)),
                batch_size=1, num_workers=1, shuffle=False)


    return train_loader, val_loader


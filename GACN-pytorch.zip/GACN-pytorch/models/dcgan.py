# %%

import torch
import torch.nn as nn
import torch.nn.functional as F

import numpy as np
# %%
def exists(val):
    return val is not None

class InitUpBlock(nn.Module):
        def __init__(self,  input_channels, out_channels, upsample = True, noisesize = 0):
            super().__init__()

            self.input_channels = input_channels

            self.upsample = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False) if upsample else None
            self.conv1 = nn.Conv2d(input_channels, out_channels, 3, 1, 1, bias = False)
            self.activation1 = nn.LeakyReLU(0.2, inplace=True)
           

        def forward(self, x, noise):
            if exists(self.upsample):
                x = self.upsample(x)
           
            x = self.conv1(x)
            x = self.activation1(x)
          
            return x

class Generator(nn.Module):
    '''
    pure Generator structure

    '''    
    def __init__(self, image_size=64, z_dim=100, conv_dim=64, channels = 1):
        
        super(Generator, self).__init__()
        self.imsize = image_size
        self.channels = channels
        self.z_dim = z_dim
        
        self.c = 1024
        self.fc = nn.Sequential(
            nn.Linear(138,  138 * 4 * 4 , bias=False)
        )
                
        self.upblock1 = InitUpBlock(138, self.c//2, True)
        self.upblock2 = InitUpBlock(self.c//2, self.c//4, True)
        self.upblock3 = InitUpBlock(self.c//4,self.c//8, True)
        self.upblock4 = InitUpBlock(self.c//8,self.c//16, True)
        self.upblock5 = InitUpBlock(self.c//16,self.c//32, True)
        

        self.last = nn.Sequential(
            nn.Conv2d(self.c//32, channels, 3, 1, 1, bias=False),
            nn.Tanh()
        )


    def forward(self, z, noise, labelv):


        z = torch.cat([z, labelv], 1)

        z = self.fc(z)
        z = z.view(z.size(0), -1, 4, 4)

        x = self.upblock1(z, noise)
        x = self.upblock2(x, noise)
        x = self.upblock3(x, noise)
        x = self.upblock4(x, noise)
        x = self.upblock5(x, noise)

        
        out = self.last(x)
   
        C = 0

        return out, C

# %%
class Discriminator(nn.Module):
    '''
    pure discriminator structure

    '''
    def __init__(self, image_size = 64, conv_dim = 64, channels = 1):
        super(Discriminator, self).__init__()
        
        ndf = 64
        
        self.discriminator = nn.Sequential(
        # --> state size. ndf x in_size/2 x in_size/2
        nn.Conv2d(3, ndf, 4, 2, 1, bias=False),
        nn.LeakyReLU(0.2, inplace=True),
        nn.Dropout(p=0.5),
        # --> state size 2ndf x x in_size/4 x in_size/4
        nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False),
        nn.BatchNorm2d(ndf * 2),
        nn.LeakyReLU(0.2, inplace=True),
        nn.Dropout(p=0.5),
        # --> state size 4ndf x in_size/8 x in_size/8
        nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False),
        nn.BatchNorm2d(ndf * 4),
        nn.LeakyReLU(0.2, inplace=True),
        nn.Dropout(p=0.5),
        # --> state size 8ndf x in_size/16 x in_size/16
        nn.Conv2d(ndf * 4, ndf * 8, 4, 2, 1, bias=False),
        nn.BatchNorm2d(ndf * 8),
        nn.LeakyReLU(0.2, inplace=True),
        nn.Dropout(p=0.5),
        #lass
        nn.Flatten()
    )
    
        self.lass1 = nn.Sequential(
                                       nn.Linear(ndf * 512, 1))
        self.lass38 = nn.Sequential(
                                       nn.Linear(ndf * 512, 38))

    def forward(self, x):

        out = self.discriminator(x)

        lass1 = self.lass1(out)
        lass38 = self.lass38(out)

        return lass1.squeeze(), lass38


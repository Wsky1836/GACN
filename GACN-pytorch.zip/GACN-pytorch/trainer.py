# %% 
"""
wgan with different loss function, used the pure dcgan structure.
"""
import os 
import time
import torch
import datetime

import torch.nn as nn 
import torchvision
from torchvision.utils import save_image
import torch.nn.functional as F

import numpy as np

import sys 
sys.path.append('.')
sys.path.append('..')

from models.dcgan import Generator, Discriminator#, DsrNet
from utils.utils import *
from torch.autograd import Variable

from functools import partial
import torchvision.models as M
import pretrainedmodels

# %%
class ResNetFinetune(nn.Module):
    finetune = True

    def __init__(self, num_classes, net_cls=M.resnet50, dropout=False):
        super().__init__()
        self.net = net_cls(pretrained=True)
        self.bn=nn.BatchNorm2d(3)
        if dropout:
            self.net.fc = nn.Sequential(
                nn.Dropout(),
                nn.Linear(self.net.fc.in_features, num_classes),
            )
        else:
         #   self.net.avgpool=nn.AdaptiveAvgPool2d(2)
            self.net.fc = nn.Linear(self.net.fc.in_features, num_classes)


class Trainer_dcgan(object):
    def __init__(self, data_loader, val_loader, config):
        super(Trainer_dcgan, self).__init__()

        # data loader 
        self.data_loader = data_loader
        self.val_loader = val_loader

        # exact model and loss 
        self.model = config.model
        self.adv_loss = config.adv_loss

        # model hyper-parameters
        self.imsize = config.img_size 
        self.g_num = config.g_num
        self.z_dim = config.z_dim
        self.channels = config.channels
        self.g_conv_dim = config.g_conv_dim
        self.d_conv_dim = config.d_conv_dim
        self.parallel = config.parallel
        self.clip_value = config.clip_value

        self.lambda_gp = config.lambda_gp
        self.epochs = config.epochs
        self.batch_size = config.batch_size
        self.num_workers = config.num_workers 
        self.g_lr = config.g_lr
        self.d_lr = config.d_lr 
        self.beta1 = config.beta1
        self.beta2 = config.beta2
        self.pretrained_model = config.pretrained_model

        self.dataset = config.dataset 
        self.use_tensorboard = config.use_tensorboard
        # path
        self.image_path = config.dataroot 
        self.log_path = config.log_path
        self.sample_path = config.sample_path
        self.log_step = config.log_step
        self.sample_step = config.sample_step
        self.version = config.version

        # path with version
        self.log_path = os.path.join(config.log_path, self.version)
        self.sample_path = os.path.join(config.sample_path, self.version)
        
        self.build_model()

    def train(self):

        logFileLoc =  '/log.txt'
        if os.path.isfile(logFileLoc):
            logger = open(logFileLoc, 'a')
        else:
            logger = open(logFileLoc, 'w')
        
        for epoch in range(self.epochs):
            # start time
            start_time = time.time()
            

            for i, (real_images, label) in enumerate(self.data_loader):  #label (64,)
                
                
                # configure input 
                real_images = tensor2var(real_images)

                
                labelv = torch.tensor(np.eye(38)[label.cpu().numpy()], dtype=real_images.dtype).cuda()
                label = label.cuda()

          
                # adversarial ground truths
                valid = tensor2var(torch.full((real_images.size(0),), 0.9)) 
                fake = tensor2var(torch.full((real_images.size(0),), 0.0))
                
                # ==================== Train D ==================
                self.D.train()
                self.G.train()

                self.D.zero_grad()

                # compute loss with real images 
                d_out_real, r38 = self.D(real_images)

                d_loss_real = self.adversarial_loss_sigmoid(d_out_real, valid)

                # noise z for generator
                z = tensor2var(torch.randn(real_images.size(0), self.z_dim)) 
                noise = tensor2var(torch.randn(real_images.size(0), self.z_dim)) 

                fake_images, _ = self.G(z,noise, labelv) 


                d_out_fake, f38 = self.D(fake_images) 

                d_loss_fake = self.adversarial_loss_sigmoid(d_out_fake, fake)

                lossR38 = F.cross_entropy(r38.squeeze(), label)
                lossF38 = F.cross_entropy(f38.squeeze(), label)

                # total d loss
                d_loss = d_loss_real + d_loss_fake + lossR38 + lossF38

                d_loss.backward()
                # update D
                self.d_optimizer.step()
        
                # train the generator every 5 steps
                if i % self.g_num == 0:

                    # =================== Train G and gumbel =====================
                    self.G.zero_grad()
                    
                    # create random noise 
                    z = tensor2var(torch.randn(real_images.size(0), self.z_dim))  #.uniform_(0., 1.)
                    noise = tensor2var(torch.randn(real_images.size(0), self.z_dim)) 
                    
                    fake_images, _ = self.G(z,noise, labelv)

                    # compute loss with fake images 
                    g_out_fake, fg38 = self.D(fake_images) # batch x n
                    g_loss_fake = self.adversarial_loss_sigmoid(g_out_fake, valid)

                    lossfg38 = F.cross_entropy(fg38.squeeze(), label)

                    # tfc = self.T(fake_images)
                    # tfcloss = F.cross_entropy(tfc, label)

                    trc = self.T(real_images)
                    trcloss = F.cross_entropy(trc, label)


                    g_loss_total = g_loss_fake + lossfg38 + trcloss
                    g_loss_total.backward()
                    # update G
                    self.g_optimizer.step()

                   # =================== Train T and gumbel =====================
                    self.T.zero_grad()

                    z = tensor2var(torch.randn(real_images.size(0), self.z_dim))  #.uniform_(0., 1.)
                    noise = tensor2var(torch.randn(real_images.size(0), self.z_dim)) 
                    
                    fake_images, _ = self.G(z,noise, labelv)

                    tfc = self.T(fake_images)
                    tfcloss = F.cross_entropy(tfc, label)

                    trc = self.T(real_images)
                    trcloss = F.cross_entropy(trc, label)

                    # print("tfcloss", tfcloss)
                    # print("trcloss", trcloss)

                    t_loss_total = tfcloss + trcloss
                    #t_loss_total = tfcloss
                    t_loss_total.backward()
                    self.t_optimizer.step()


            # print out log info
            if (epoch) % self.log_step == 0:
                elapsed = time.time() - start_time
                elapsed = str(datetime.timedelta(seconds=elapsed))

                self.T.eval()
                outputs = [validation_step(self.T, batch) for batch in self.val_loader]
                temp = validation_epoch_end(outputs)

                logger.write("\n%d\t\t%.4f\t\t\t\t" % (epoch, temp))
                logger.flush()

                print("Elapsed [{}], G_step [{}/{}], D_step[{}/{}], d_out_gp: {:.4f}, g_loss: {:.4f}, lossfg38: {:.4f},lossR38: {:.4f},lossF38: {:.4f}"
                    .format(elapsed, epoch, self.epochs, epoch,
                            self.epochs, d_loss.item(), g_loss_fake.item(), lossfg38.item(),lossR38.item(),lossF38.item()))

            # sample images 
            if (epoch) % self.sample_step == 0:
                self.G.eval()
                # save real image
                save_sample(self.sample_path + '/real_images/', real_images, epoch)
                
                with torch.no_grad():
                    fixed_z = tensor2var(torch.randn(real_images.size(0), self.z_dim))
                    fixed_noise = tensor2var(torch.randn(real_images.size(0), self.z_dim)) 
                    
                    fake_images, _ = self.G(fixed_z, fixed_noise, labelv)
                    # save fake image 
                    save_sample(self.sample_path + '/fake_images/', fake_images, epoch)

                    # self.T.eval()
                    # outputs = [validation_step(self.T, batch) for batch in self.val_loader]
                    # temp = validation_epoch_end(outputs)

                    # logger.write("\n%d\t\t%.4f\t\t\t\t" % (epoch, temp))
                    # logger.flush()
                    
                    model_file_name = '/home/wick/GACN/save/' + 'g'+str(epoch) + '.pth'
                    state = {"epoch": epoch, "model": self.G.state_dict()}
                    torch.save(state, model_file_name)

                    model_file_name = '/home/wick/GACN/save/' + 'd'+str(epoch) + '.pth'
                    state = {"epoch": epoch, "model": self.D.state_dict()}
                    torch.save(state, model_file_name)

                    model_file_name = '/home/wick/GACN/save/' + 't'+str(epoch) + '.pth'
                    state = {"epoch": epoch, "model": self.T.state_dict()}
                    torch.save(state, model_file_name)

        logger.close()

    def build_model(self):

        self.G = Generator(image_size = self.imsize, z_dim = self.z_dim, conv_dim = self.g_conv_dim, channels = self.channels).cuda()
        self.D = Discriminator(image_size = self.imsize, conv_dim = self.d_conv_dim, channels = self.channels).cuda()


        self.T=torchvision.models.resnet18(pretrained=True)
        num_features=self.T.fc.in_features
        self.T.fc=nn.Linear(num_features,38)
        self.T=self.T.cuda()

        #self.T = model()
        # checkpoint = torch.load('/home/wick/GACN/t.pth')
        # self.T.load_state_dict(checkpoint['model'])

        # apply the weights_init to randomly initialize all weights
        # to mean=0, stdev=0.2
        self.G.apply(weights_init)
        self.D.apply(weights_init)
        #self.T.apply(weights_init)
        
        # optimizer 
        self.g_optimizer = torch.optim.Adam(self.G.parameters(), self.g_lr, [self.beta1, self.beta2])
        self.d_optimizer = torch.optim.Adam(self.D.parameters(), self.d_lr, [self.beta1, self.beta2])
        self.t_optimizer = torch.optim.Adam(self.T.parameters(), 1e-4, amsgrad=True,weight_decay=1e-4)
        #self.t_optimizer = torch.optim.Adam(self.T.fc.parameters(),lr = 1e-3,amsgrad=True,weight_decay=1e-4)

        # for orignal gan loss function
        self.adversarial_loss_sigmoid = nn.BCEWithLogitsLoss()

        # print networks
        print(self.G)
        print(self.D)

    def build_tensorboard(self):
        from torch.utils.tensorboard import SummaryWriter
        self.logger = SummaryWriter(self.log_path)

    def save_image_tensorboard(self, images, text, step):
        if step % 100 == 0:
            img_grid = torchvision.utils.make_grid(images, nrow=8)

            self.logger.add_image(text + str(step), img_grid, step)
            self.logger.close()
